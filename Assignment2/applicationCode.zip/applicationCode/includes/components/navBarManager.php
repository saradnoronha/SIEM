<!DOCTYPE html> <!--defines document type HTML5-->
<html>

<body id="background">

<div id="Nav">
	<ul>
		<li> <a href="../Formula1-Bets.php"> &#127937 </a> </li>
		<li> <a href="../listCalendar.php"> <i><b>Calendar </a></li>
		<li> <a href="../listDrivers.php"> Drivers </a></li>
		<li> <a href="../listOdds.php"> Odds </i></a></li>
		<li style="float:right" class ="dropdown"> <a class="dropbtn">Login </b></a>
			<div class="dropdown-content">
				<a href="listSearchUsers.php">Users</a>
				<a href="listSearchBets.php">Bets </a>
				<a href="../../actions/actionLogout.php">Logout</a>
			</div>
		</li>
	</ul>
</div>
</body>
</html>