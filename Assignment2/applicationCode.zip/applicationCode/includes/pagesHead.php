<!DOCTYPE html> <!--defines document type HTML5-->
<html>
<head>
	<meta charset ="UTF-8">
	<title>F1-Bets</title> <!-- specifies a title for the html page (showed in the browser window) -->
	<link id="logo" rel="icon" type="imagem/png" href="../images/logo.png"/>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
</html>